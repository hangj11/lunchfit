import LunchfitApp from '@/components/lunchfit/App'

export default function Page() {
  return <LunchfitApp />
}

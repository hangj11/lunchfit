import React from 'react';
import { GroupOrder, GroupMember, Restaurant, MenuItem, MenuOption } from '../types';
import { calculateSettlement, generateSettlementShareText } from '../utils/settlement';
import { 
  Users, 
  Clock, 
  CheckCircle2, 
  Copy, 
  Plus, 
  Trash2, 
  Share2, 
  AlertCircle, 
  ArrowRight, 
  Check, 
  DollarSign, 
  Percent, 
  Sparkles, 
  Store,
  ChevronDown,
  ChevronUp,
  UserPlus
} from 'lucide-react';

interface GroupOrderViewProps {
  order: GroupOrder;
  restaurants: Restaurant[];
  onUpdateOrder: (updated: GroupOrder) => void;
  onCompleteOrder: () => void;
  onCancelOrder: () => void;
  onSwitchRestaurant: (newRestaurantId: string) => void;
}

export const GroupOrderView: React.FC<GroupOrderViewProps> = ({
  order,
  restaurants,
  onUpdateOrder,
  onCompleteOrder,
  onCancelOrder,
  onSwitchRestaurant,
}) => {
  const currentRestaurant = restaurants.find((r) => r.id === order.restaurantId) || restaurants[0];
  const [activeMemberId, setActiveMemberId] = React.useState<string>(
    order.members[0]?.id || ''
  );
  const [newMemberName, setNewMemberName] = React.useState('');
  const [copiedLink, setCopiedLink] = React.useState(false);
  const [copiedSettlementText, setCopiedSettlementText] = React.useState(false);
  const [showMenuDrawer, setShowMenuDrawer] = React.useState(false);

  // Settlement computation
  const settlement = calculateSettlement(order);

  // Copy share invite link
  const handleCopyInviteLink = () => {
    navigator.clipboard.writeText(
      `${window.location.origin}?group=${order.id}`
    );
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // Copy settlement text
  const handleCopySettlementText = () => {
    const text = generateSettlementShareText(order, settlement);
    navigator.clipboard.writeText(text);
    setCopiedSettlementText(true);
    setTimeout(() => setCopiedSettlementText(false), 2000);
  };

  // Add a new member
  const handleAddMember = (nameToAdd?: string) => {
    const name = nameToAdd || newMemberName.trim();
    if (!name) return;

    const newMember: GroupMember = {
      id: `member-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      name,
      avatarColor: ['bg-amber-500', 'bg-blue-500', 'bg-emerald-500', 'bg-purple-500', 'bg-rose-500'][
        order.members.length % 5
      ],
      isCreator: false,
      hasSubmitted: false,
      isPaid: false,
      items: [],
    };

    const updated = {
      ...order,
      members: [...order.members, newMember],
    };
    onUpdateOrder(updated);
    setActiveMemberId(newMember.id);
    setNewMemberName('');
  };

  // Quick simulation: Populate realistic colleagues with orders
  const handleSimulateColleagues = () => {
    const menus = currentRestaurant.menus;
    if (menus.length === 0) return;

    const mockColleagues: GroupMember[] = [
      {
        id: 'member-creator',
        name: order.creatorName || '나 (그룹장)',
        avatarColor: 'bg-amber-500',
        isCreator: true,
        hasSubmitted: true,
        isPaid: true,
        items: [
          {
            id: `item-creator-1`,
            menuId: menus[0].id,
            menuName: menus[0].name,
            unitPrice: menus[0].price,
            quantity: 1,
            selectedOptions: menus[0].options ? [menus[0].options[0]] : [],
            optionsTotalPrice: menus[0].options ? menus[0].options[0].price : 0,
            memberId: 'member-creator',
          },
        ],
      },
      {
        id: 'member-kim',
        name: '김대리',
        avatarColor: 'bg-blue-500',
        isCreator: false,
        hasSubmitted: true,
        isPaid: false,
        items: [
          {
            id: `item-kim-1`,
            menuId: (menus[1] || menus[0]).id,
            menuName: (menus[1] || menus[0]).name,
            unitPrice: (menus[1] || menus[0]).price,
            quantity: 1,
            selectedOptions: [],
            optionsTotalPrice: 0,
            memberId: 'member-kim',
          },
        ],
      },
      {
        id: 'member-lee',
        name: '이선임',
        avatarColor: 'bg-emerald-500',
        isCreator: false,
        hasSubmitted: true,
        isPaid: true,
        items: [
          {
            id: `item-lee-1`,
            menuId: (menus[2] || menus[0]).id,
            menuName: (menus[2] || menus[0]).name,
            unitPrice: (menus[2] || menus[0]).price,
            quantity: 1,
            selectedOptions: [],
            optionsTotalPrice: 0,
            memberId: 'member-lee',
          },
        ],
      },
      {
        id: 'member-park',
        name: '박팀장',
        avatarColor: 'bg-purple-500',
        isCreator: false,
        hasSubmitted: true,
        isPaid: false,
        items: [
          {
            id: `item-park-1`,
            menuId: menus[0].id,
            menuName: menus[0].name,
            unitPrice: menus[0].price,
            quantity: 1,
            selectedOptions: menus[0].options?.slice(0, 2) || [],
            optionsTotalPrice: (menus[0].options?.slice(0, 2) || []).reduce((s, o) => s + o.price, 0),
            memberId: 'member-park',
          },
        ],
      },
    ];

    onUpdateOrder({
      ...order,
      members: mockColleagues,
      deliveryFee: 3000,
      discountAmount: 2000,
      status: 'REVIEW',
    });
    setActiveMemberId('member-kim');
  };

  // Add item for current active member
  const handleAddItemForActiveMember = (menu: MenuItem, option?: MenuOption) => {
    const updatedMembers = order.members.map((member) => {
      if (member.id !== activeMemberId) return member;

      const newItem = {
        id: `item-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
        menuId: menu.id,
        menuName: menu.name,
        unitPrice: menu.price,
        quantity: 1,
        selectedOptions: option ? [option] : [],
        optionsTotalPrice: option ? option.price : 0,
        memberId: member.id,
      };

      return {
        ...member,
        hasSubmitted: true,
        items: [...member.items, newItem],
      };
    });

    onUpdateOrder({ ...order, members: updatedMembers });
  };

  // Remove item
  const handleRemoveItem = (memberId: string, itemId: string) => {
    const updatedMembers = order.members.map((member) => {
      if (member.id !== memberId) return member;
      const filtered = member.items.filter((i) => i.id !== itemId);
      return {
        ...member,
        items: filtered,
        hasSubmitted: filtered.length > 0,
      };
    });
    onUpdateOrder({ ...order, members: updatedMembers });
  };

  // Toggle member payment status
  const handleTogglePaid = (memberId: string) => {
    const updatedMembers = order.members.map((m) =>
      m.id === memberId ? { ...m, isPaid: !m.isPaid } : m
    );
    onUpdateOrder({ ...order, members: updatedMembers });
  };

  // Delete member
  const handleDeleteMember = (memberId: string) => {
    if (order.members.length <= 1) return;
    const remaining = order.members.filter((m) => m.id !== memberId);
    onUpdateOrder({ ...order, members: remaining });
    if (activeMemberId === memberId) {
      setActiveMemberId(remaining[0].id);
    }
  };

  const activeMember = order.members.find((m) => m.id === activeMemberId) || order.members[0];

  // Aggregated item quantities across all members
  const aggregatedMenuMap = new Map<string, { name: string; count: number; total: number }>();
  order.members.forEach((m) => {
    m.items.forEach((item) => {
      const existing = aggregatedMenuMap.get(item.menuName);
      const itemTotal = (item.unitPrice + item.optionsTotalPrice) * item.quantity;
      if (existing) {
        existing.count += item.quantity;
        existing.total += itemTotal;
      } else {
        aggregatedMenuMap.set(item.menuName, {
          name: item.menuName,
          count: item.quantity,
          total: itemTotal,
        });
      }
    });
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner: Group Info & Status */}
      <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
              <span>그룹장: {order.creatorName}</span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1 font-semibold text-amber-700">
                <Store className="w-3.5 h-3.5" />
                {order.restaurantName}
              </span>
              <span aria-hidden="true">·</span>
              <span>{order.restaurantCategory}</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <span>{order.title}</span>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 font-semibold">
                {order.status === 'CONFIRMED' ? '주문 확정됨' : '메뉴 취합 중'}
              </span>
            </h1>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleCopyInviteLink}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
              <span>{copiedLink ? '링크 복사됨!' : '참여 링크 공유'}</span>
            </button>

            <button
              onClick={handleSimulateColleagues}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-amber-900 bg-amber-100 hover:bg-amber-200 rounded-xl transition-colors"
              title="동료 3명의 가상 주문을 1초 만에 자동 생성하여 정산까지 바로 테스트해보세요"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>동료 가상 참여 자동 채우기</span>
            </button>
          </div>
        </div>

        {/* Change restaurant selector */}
        <div className="pt-3 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <Clock className="w-3.5 h-3.5 text-amber-600" />
            <span>주문 마감: <strong>{order.deadlineTimeStr}</strong>까지 (약 {order.deadlineMinutesRemaining}분 남음)</span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">식당 변경:</span>
            <select
              value={order.restaurantId}
              onChange={(e) => onSwitchRestaurant(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-amber-500 font-medium"
            >
              {restaurants.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name} ({r.category})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Main 2-Column Split: Left (Members & Menu Selector), Right (Aggregated Bill & 1/N Settlement) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Member Management & Item Picking */}
        <div className="lg:col-span-7 space-y-4">
          {/* Member Tabs */}
          <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Users className="w-4 h-4 text-amber-600" />
                <span>참여자 목록 ({order.members.length}명)</span>
              </h2>
              <span className="text-xs text-slate-400">
                참여자를 누르고 아래 메뉴를 추가하세요
              </span>
            </div>

            {/* Member avatar chips */}
            <div className="flex flex-wrap gap-2">
              {order.members.map((member) => {
                const isSelected = member.id === activeMemberId;
                const itemCount = member.items.reduce((s, i) => s + i.quantity, 0);

                return (
                  <button
                    key={member.id}
                    onClick={() => setActiveMemberId(member.id)}
                    className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                      isSelected
                        ? 'bg-slate-900 text-white shadow-xs'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                  >
                    <span
                      className={`w-2.5 h-2.5 rounded-full ${
                        member.hasSubmitted ? 'bg-emerald-400' : 'bg-amber-400'
                      }`}
                    />
                    <span>{member.name}</span>
                    {itemCount > 0 && (
                      <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-white/20 text-current">
                        {itemCount}개
                      </span>
                    )}
                  </button>
                );
              })}

              {/* Add member input */}
              <div className="flex items-center gap-1.5">
                <input
                  type="text"
                  placeholder="동료 이름"
                  value={newMemberName}
                  onChange={(e) => setNewMemberName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddMember()}
                  className="w-24 px-2 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-amber-500"
                />
                <button
                  onClick={() => handleAddMember()}
                  className="p-1.5 text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-medium"
                  title="참여자 추가"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Active Member's Plate */}
            {activeMember && (
              <div className="p-4 rounded-2xl bg-amber-50/40 border border-amber-200/60 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-slate-900">
                      {activeMember.name}님의 식판
                    </span>
                    {activeMember.isCreator && (
                      <span className="text-[10px] font-semibold text-amber-800 bg-amber-100 px-1.5 py-0.5 rounded">
                        그룹장
                      </span>
                    )}
                  </div>

                  {!activeMember.isCreator && order.members.length > 1 && (
                    <button
                      onClick={() => handleDeleteMember(activeMember.id)}
                      className="text-xs text-rose-500 hover:text-rose-700 flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>참여자 삭제</span>
                    </button>
                  )}
                </div>

                {activeMember.items.length === 0 ? (
                  <div className="py-6 text-center text-xs text-slate-500">
                    아직 담긴 메뉴가 없습니다. 아래 메뉴판에서 원하는 메뉴를 클릭해 담아주세요!
                  </div>
                ) : (
                  <div className="space-y-2">
                    {activeMember.items.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between p-2.5 bg-white rounded-xl border border-slate-200 text-xs shadow-2xs"
                      >
                        <div className="min-w-0 pr-2">
                          <div className="font-semibold text-slate-900 truncate">
                            {item.menuName}
                          </div>
                          {item.selectedOptions.length > 0 && (
                            <div className="text-[11px] text-slate-500">
                              + {item.selectedOptions.map((o) => o.name).join(', ')}
                            </div>
                          )}
                        </div>
                        <div className="flex items-center gap-3 shrink-0">
                          <span className="font-bold text-slate-900 tabular-nums">
                            {((item.unitPrice + item.optionsTotalPrice) * item.quantity).toLocaleString()}원
                          </span>
                          <button
                            onClick={() => handleRemoveItem(activeMember.id, item.id)}
                            className="text-slate-400 hover:text-rose-500"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Restaurant Menu Selector for current active member */}
          <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  {currentRestaurant.name} 메뉴판
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  클릭하면 현재 선택된 <strong>{activeMember?.name}</strong>님에게 담깁니다.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {currentRestaurant.menus.map((menu) => (
                <div
                  key={menu.id}
                  className="p-3 rounded-2xl border border-slate-200 hover:border-amber-400 transition-colors bg-white flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-1 mb-1">
                      <h4 className="text-xs font-bold text-slate-900">
                        {menu.name}
                      </h4>
                      <span className="text-xs font-bold text-slate-900 tabular-nums shrink-0">
                        {menu.price.toLocaleString()}원
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 line-clamp-2">
                      {menu.description}
                    </p>
                    <div className="text-[10px] text-slate-400 mt-1 flex items-center gap-1.5">
                      <span>단백질 {menu.nutrition.proteinGrams}g</span>
                      <span>·</span>
                      <span>포만감 {menu.fullnessScore}/5</span>
                    </div>
                  </div>

                  <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                    {menu.options && menu.options.length > 0 ? (
                      <span className="text-[10px] text-slate-400">
                        옵션 {menu.options.length}개
                      </span>
                    ) : (
                      <span className="text-[10px] text-slate-400">기본 단품</span>
                    )}

                    <button
                      onClick={() => handleAddItemForActiveMember(menu)}
                      className="px-2.5 py-1 text-xs font-semibold text-slate-900 bg-amber-100 hover:bg-amber-200 rounded-lg transition-colors flex items-center gap-1"
                    >
                      <Plus className="w-3 h-3" />
                      <span>담기</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Aggregated Bill & 1/N Settlement */}
        <div className="lg:col-span-5 space-y-4">
          {/* Order Aggregation Summary */}
          <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-xs space-y-4">
            <h2 className="text-sm font-bold text-slate-900 flex items-center justify-between">
              <span>전체 주문 취합 ({aggregatedMenuMap.size}종류)</span>
              <span className="text-xs font-semibold text-slate-500">
                총 {order.members.reduce((s, m) => s + m.items.length, 0)}개 메뉴
              </span>
            </h2>

            {/* Aggregated list */}
            {aggregatedMenuMap.size === 0 ? (
              <div className="py-8 text-center text-xs text-slate-400">
                아직 취합된 주문이 없습니다.
              </div>
            ) : (
              <div className="space-y-1.5 text-xs">
                {Array.from(aggregatedMenuMap.values()).map((item, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between py-1.5 border-b border-slate-100 last:border-none"
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-slate-800">{item.name}</span>
                      <span className="text-slate-400">x{item.count}</span>
                    </div>
                    <span className="font-bold text-slate-900 tabular-nums">
                      {item.total.toLocaleString()}원
                    </span>
                  </div>
                ))}
              </div>
            )}

            {/* Extra Cost & Discount Inputs */}
            <div className="pt-3 border-t border-slate-200 space-y-2 text-xs">
              <div className="flex items-center justify-between gap-2">
                <span className="text-slate-600 font-medium flex items-center gap-1">
                  <span>배달비 / 포장비</span>
                </span>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    step={500}
                    value={order.deliveryFee}
                    onChange={(e) =>
                      onUpdateOrder({ ...order, deliveryFee: Number(e.target.value) || 0 })
                    }
                    className="w-20 px-2 py-1 text-right text-xs bg-slate-50 border border-slate-200 rounded-lg tabular-nums font-bold"
                  />
                  <span>원</span>
                </div>
              </div>

              <div className="flex items-center justify-between gap-2">
                <span className="text-slate-600 font-medium flex items-center gap-1">
                  <span>할인 쿠폰 / 포인트</span>
                </span>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    step={500}
                    value={order.discountAmount}
                    onChange={(e) =>
                      onUpdateOrder({ ...order, discountAmount: Number(e.target.value) || 0 })
                    }
                    className="w-20 px-2 py-1 text-right text-xs bg-slate-50 border border-slate-200 rounded-lg tabular-nums font-bold text-amber-700"
                  />
                  <span>원</span>
                </div>
              </div>

              {/* Total Final Payable Amount */}
              <div className="p-3 rounded-2xl bg-slate-900 text-white flex items-center justify-between mt-3">
                <span className="text-xs font-semibold text-slate-300">
                  최종 결제 예정 총액
                </span>
                <span className="text-lg font-bold tabular-nums">
                  {settlement.finalTotalAmount.toLocaleString()}원
                </span>
              </div>
            </div>
          </div>

          {/* 1/N Settlement Card */}
          <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <DollarSign className="w-4 h-4 text-emerald-600" />
                <span>1/N 스마트 정산</span>
              </h2>
              <button
                onClick={handleCopySettlementText}
                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
              >
                {copiedSettlementText ? (
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
                <span>{copiedSettlementText ? '카톡 문구 복사됨' : '정산 카톡 복사'}</span>
              </button>
            </div>

            {/* Settlement Method Switcher (FR-12) */}
            <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-100 rounded-xl text-xs font-semibold">
              <button
                onClick={() => onUpdateOrder({ ...order, settlementMethod: 'EQUAL' })}
                className={`py-2 rounded-lg transition-all ${
                  order.settlementMethod === 'EQUAL'
                    ? 'bg-white text-slate-900 shadow-2xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                균등 1/N 분할
              </button>
              <button
                onClick={() => onUpdateOrder({ ...order, settlementMethod: 'BY_ORDER' })}
                className={`py-2 rounded-lg transition-all ${
                  order.settlementMethod === 'BY_ORDER'
                    ? 'bg-white text-slate-900 shadow-2xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                개별 주문 금액 기준
              </button>
            </div>

            <div className="text-[11px] text-slate-500">
              {order.settlementMethod === 'EQUAL'
                ? '총 결제 금액을 인원 수대로 똑같이 나눕니다 (원 단위 단수 보정 포함).'
                : '각자 주문한 메뉴 금액에 배달비와 할인을 공정하게 배분합니다.'}
            </div>

            {/* Member Settlement Breakdown Table */}
            <div className="space-y-2 pt-1">
              {settlement.memberDetails.map((m) => (
                <div
                  key={m.memberId}
                  className={`p-3 rounded-2xl border transition-all text-xs ${
                    m.isPaid
                      ? 'bg-emerald-50/50 border-emerald-200'
                      : 'bg-white border-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900">{m.memberName}</span>
                      {m.isCreator && (
                        <span className="text-[10px] text-amber-700 bg-amber-100 px-1.5 py-0.2 rounded font-medium">
                          그룹장
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-slate-900 tabular-nums">
                        {m.finalAmount.toLocaleString()}원
                      </span>

                      {/* Payment Toggle Checkbox */}
                      <button
                        onClick={() => handleTogglePaid(m.memberId)}
                        className={`px-2 py-0.5 rounded text-[11px] font-semibold transition-colors flex items-center gap-1 ${
                          m.isPaid
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                        title="송금 완료 여부 토글"
                      >
                        {m.isPaid ? <Check className="w-3 h-3" /> : null}
                        <span>{m.isPaid ? '송금완료' : '미송금'}</span>
                      </button>
                    </div>
                  </div>

                  {order.settlementMethod === 'BY_ORDER' && (
                    <div className="text-[11px] text-slate-400 flex items-center justify-between">
                      <span>
                        메뉴 {m.foodAmount.toLocaleString()}원
                        {m.deliveryShare > 0 && ` + 배달비 ${m.deliveryShare.toLocaleString()}원`}
                        {m.discountShare > 0 && ` - 할인 ${m.discountShare.toLocaleString()}원`}
                      </span>
                      {m.roundingAdjustment !== 0 && (
                        <span className="text-amber-700">단수 보정 {m.roundingAdjustment > 0 ? `+${m.roundingAdjustment}` : m.roundingAdjustment}원</span>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Collection Progress */}
            <div className="pt-3 border-t border-slate-100 space-y-1.5 text-xs">
              <div className="flex items-center justify-between font-medium">
                <span className="text-slate-500">입금 수합 현황</span>
                <span className="text-slate-900 font-bold tabular-nums">
                  {settlement.totalCollected.toLocaleString()}원 / {settlement.finalTotalAmount.toLocaleString()}원
                </span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-500 h-full transition-all duration-300"
                  style={{
                    width: `${
                      settlement.finalTotalAmount > 0
                        ? Math.min(100, (settlement.totalCollected / settlement.finalTotalAmount) * 100)
                        : 0
                    }%`,
                  }}
                />
              </div>
            </div>

            {/* Order Confirmation CTA */}
            <div className="pt-2">
              <button
                onClick={onCompleteOrder}
                className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl text-xs sm:text-sm font-bold shadow-md transition-all flex items-center justify-center gap-2"
              >
                <span>주문 확정 및 픽업 상태 보기</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

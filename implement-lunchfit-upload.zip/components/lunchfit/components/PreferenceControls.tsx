import React from 'react';
import { UserPreferences, PreferenceTag, MealStyle } from '../types';
import { Clock, Wallet, Zap, ShieldCheck, Flame, Salad, ShoppingBag, User, Users } from 'lucide-react';

interface PreferenceControlsProps {
  preferences: UserPreferences;
  onChangePreferences: (prefs: UserPreferences) => void;
  onReset: () => void;
  onStartGroupOrder: () => void;
}

const PREFERENCE_TAG_OPTIONS: Array<{
  tag: PreferenceTag;
  label: string;
  icon: React.ReactNode;
}> = [
  { tag: 'FAST', label: '빠른 식사', icon: <Zap className="w-3.5 h-3.5 text-amber-500" /> },
  { tag: 'FULLNESS', label: '든든한 포만감', icon: <Flame className="w-3.5 h-3.5 text-orange-500" /> },
  { tag: 'PROTEIN', label: '고단백 식단', icon: <ShieldCheck className="w-3.5 h-3.5 text-blue-500" /> },
  { tag: 'HEALTHY', label: '건강·클린', icon: <Salad className="w-3.5 h-3.5 text-emerald-500" /> },
  { tag: 'BUDGET', label: '착한 가성비', icon: <Wallet className="w-3.5 h-3.5 text-purple-500" /> },
  { tag: 'TAKEOUT', label: '포장·픽업', icon: <ShoppingBag className="w-3.5 h-3.5 text-teal-500" /> },
];

export const PreferenceControls: React.FC<PreferenceControlsProps> = ({
  preferences,
  onChangePreferences,
  onReset,
  onStartGroupOrder,
}) => {
  const timePresets = [30, 45, 60, 75];
  const budgetPresets = [10000, 12000, 14000, 18000];

  const handleTimeChange = (minutes: number) => {
    onChangePreferences({ ...preferences, availableTimeMinutes: minutes });
  };

  const handleBudgetChange = (budget: number) => {
    onChangePreferences({ ...preferences, budgetWon: budget });
  };

  const handleToggleTag = (tag: PreferenceTag) => {
    const exists = preferences.selectedTags.includes(tag);
    const updated = exists
      ? preferences.selectedTags.filter((t) => t !== tag)
      : [...preferences.selectedTags, tag];
    onChangePreferences({ ...preferences, selectedTags: updated });
  };

  const handleMealStyleChange = (style: MealStyle) => {
    onChangePreferences({ ...preferences, mealStyle: style });
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-4 sm:p-6 mb-6 transition-all">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 mb-4 border-b border-slate-100">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
            오늘 점심, 어떤 조건으로 드실래요?
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            이동·대기·식사시간과 예산을 계산해 딱 맞는 선택지를 골라드립니다.
          </p>
        </div>
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={onReset}
            className="text-xs text-slate-500 hover:text-slate-800 underline underline-offset-4 py-1 px-2"
          >
            기본값 초기화
          </button>
          <button
            onClick={onStartGroupOrder}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-900 bg-amber-100 hover:bg-amber-200 rounded-lg transition-colors"
          >
            <Users className="w-3.5 h-3.5" />
            <span>팀원과 함께 주문하기</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-5">
        {/* 1. Time Input */}
        <div className="lg:col-span-4 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-amber-600" />
              식사 가능 시간
            </span>
            <span className="text-sm font-bold text-slate-900 tabular-nums">
              {preferences.availableTimeMinutes}분 이내
            </span>
          </div>

          <div className="grid grid-cols-4 gap-1.5">
            {timePresets.map((mins) => (
              <button
                key={mins}
                type="button"
                onClick={() => handleTimeChange(mins)}
                className={`min-h-10 py-2.5 px-1 text-xs font-medium rounded-lg transition-all text-center ${
                  preferences.availableTimeMinutes === mins
                    ? 'bg-slate-900 text-white shadow-xs font-semibold'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {mins}분
              </button>
            ))}
          </div>

          <input
            type="range"
            min={20}
            max={90}
            step={5}
            value={preferences.availableTimeMinutes}
            onChange={(e) => handleTimeChange(Number(e.target.value))}
            className="w-full accent-amber-500 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
          />
        </div>

        {/* 2. Budget Input */}
        <div className="lg:col-span-4 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
              <Wallet className="w-3.5 h-3.5 text-amber-600" />
              1인당 점심 예산
            </span>
            <span className="text-sm font-bold text-slate-900 tabular-nums">
              {preferences.budgetWon.toLocaleString()}원 이하
            </span>
          </div>

          <div className="grid grid-cols-4 gap-1.5">
            {budgetPresets.map((won) => (
              <button
                key={won}
                type="button"
                onClick={() => handleBudgetChange(won)}
                className={`min-h-10 py-2.5 px-1 text-xs font-medium rounded-lg transition-all text-center ${
                  preferences.budgetWon === won
                    ? 'bg-slate-900 text-white shadow-xs font-semibold'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {(won / 10000).toFixed(1).replace('.0', '')}만
              </button>
            ))}
          </div>

          <input
            type="range"
            min={8000}
            max={25000}
            step={1000}
            value={preferences.budgetWon}
            onChange={(e) => handleBudgetChange(Number(e.target.value))}
            className="w-full accent-amber-500 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
          />
        </div>

        {/* 3. Meal Style */}
        <div className="lg:col-span-4 space-y-2.5">
          <span className="text-xs font-semibold text-slate-700 block">
            식사 형태
          </span>
          <div className="grid grid-cols-3 gap-1.5">
            <button
              type="button"
              onClick={() => handleMealStyleChange('solo')}
              className={`flex items-center justify-center gap-1 py-2 text-xs font-medium rounded-lg transition-all ${
                preferences.mealStyle === 'solo'
                  ? 'bg-amber-600 text-white shadow-xs font-semibold'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <User className="w-3 h-3" />
              <span>혼밥</span>
            </button>
            <button
              type="button"
              onClick={() => handleMealStyleChange('together')}
              className={`flex items-center justify-center gap-1 py-2 text-xs font-medium rounded-lg transition-all ${
                preferences.mealStyle === 'together'
                  ? 'bg-amber-600 text-white shadow-xs font-semibold'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Users className="w-3 h-3" />
              <span>매장 식사</span>
            </button>
            <button
              type="button"
              onClick={() => handleMealStyleChange('takeout')}
              className={`flex items-center justify-center gap-1 py-2 text-xs font-medium rounded-lg transition-all ${
                preferences.mealStyle === 'takeout'
                  ? 'bg-amber-600 text-white shadow-xs font-semibold'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <ShoppingBag className="w-3 h-3" />
              <span>포장·픽업</span>
            </button>
          </div>
          <div className="text-[11px] text-slate-400">
            {preferences.mealStyle === 'takeout' && '사무실 복귀 후 바로 식사할 수 있도록 포장 픽업을 우선 추천합니다.'}
            {preferences.mealStyle === 'solo' && '1인석이 편안하고 회전율이 빠른 곳을 우선 추천합니다.'}
            {preferences.mealStyle === 'together' && '동료 2~4인이 함께 앉기 좋은 테이블 석 위주로 추천합니다.'}
          </div>
        </div>
      </div>

      {/* Preference Tags */}
      <div className="mt-4 pt-3 border-t border-slate-100">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-slate-400 font-medium mr-1">
            원하는 테마:
          </span>
          {PREFERENCE_TAG_OPTIONS.map((opt) => {
            const isSelected = preferences.selectedTags.includes(opt.tag);
            return (
              <button
                key={opt.tag}
                type="button"
                onClick={() => handleToggleTag(opt.tag)}
                className={`flex items-center gap-1.5 min-h-10 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                  isSelected
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {opt.icon}
                <span>{opt.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

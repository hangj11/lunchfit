import React from 'react';
import { Restaurant, MenuItem, MenuOption } from '../types';
import { X, Clock, MapPin, Phone, Star, ShieldCheck, CheckCircle2, Users, ShoppingBag, Plus, Minus, ExternalLink } from 'lucide-react';

interface RestaurantDetailModalProps {
  restaurant: Restaurant;
  onClose: () => void;
  onSelectMenuForSoloOrder: (menu: MenuItem, options: MenuOption[]) => void;
  onStartGroupOrder: (restaurant: Restaurant) => void;
}

export const RestaurantDetailModal: React.FC<RestaurantDetailModalProps> = ({
  restaurant,
  onClose,
  onSelectMenuForSoloOrder,
  onStartGroupOrder,
}) => {
  const [selectedMenu, setSelectedMenu] = React.useState<MenuItem>(restaurant.menus[0]);
  const [selectedOptions, setSelectedOptions] = React.useState<MenuOption[]>([]);
  const [showCatchtableModal, setShowCatchtableModal] = React.useState(false);

  const toggleOption = (opt: MenuOption) => {
    const exists = selectedOptions.some((o) => o.id === opt.id);
    if (exists) {
      setSelectedOptions(selectedOptions.filter((o) => o.id !== opt.id));
    } else {
      setSelectedOptions([...selectedOptions, opt]);
    }
  };

  const optionsTotal = selectedOptions.reduce((acc, opt) => acc + opt.price, 0);
  const totalItemPrice = selectedMenu.price + optionsTotal;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Header Bar */}
        <div className="sticky top-0 z-20 flex items-center justify-between px-6 py-4 bg-white/95 backdrop-blur-md border-b border-slate-100">
          <div>
            <div className="text-xs text-slate-500 font-medium">
              {restaurant.category} · 평점 {restaurant.rating} ★
            </div>
            <h2 className="text-lg font-bold text-slate-900 tracking-tight">
              {restaurant.name}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 max-h-[75vh] overflow-y-auto space-y-6">
          {/* Restaurant Banner & Fast Stats */}
          <div className="rounded-2xl bg-slate-50 border border-slate-200/80 p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-1.5 text-slate-700 font-semibold">
                <Clock className="w-4 h-4 text-amber-600" />
                <span>총 소요 예상 {restaurant.totalEstimatedMinutes}분</span>
                <span className="text-slate-400 font-normal">
                  (도보 {restaurant.walkMinutes}분 + 조리 {restaurant.prepWaitMinutes}분 + 식사 {restaurant.eatMinutes}분)
                </span>
              </div>
              <div className="flex items-center gap-1 text-slate-600">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                <span>{restaurant.locationDescription}</span>
              </div>
            </div>

            <div className="text-xs text-slate-600 space-y-1 pt-2 border-t border-slate-200/60">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-700">영업시간:</span>
                <span>{restaurant.businessHours}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-700">매장전화:</span>
                <span>{restaurant.phone}</span>
              </div>
              {restaurant.notice && (
                <div className="text-amber-800 bg-amber-50/80 p-2 rounded-lg font-medium">
                  💡 {restaurant.notice}
                </div>
              )}
            </div>

            {/* Integration tags */}
            <div className="flex flex-wrap items-center gap-2 pt-1">
              {restaurant.isRealtimePartner ? (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold bg-emerald-100 text-emerald-800">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  실시간 주문·웨이팅 연동 매장
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium bg-slate-200 text-slate-700">
                  매장 추정 데이터 (사전 전화 권장)
                </span>
              )}

              {restaurant.reservationPlatform === 'CATCHTABLE' && (
                <button
                  onClick={() => setShowCatchtableModal(true)}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold bg-red-50 text-red-700 hover:bg-red-100 transition-colors"
                >
                  <ExternalLink className="w-3 h-3 text-red-600" />
                  캐치테이블 원격 줄서기 확인
                </button>
              )}
            </div>
          </div>

          {/* Menu Selection Section */}
          <div>
            <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center justify-between">
              <span>식당 대표 메뉴</span>
              <span className="text-xs font-normal text-slate-400">메뉴를 선택해 영양성분과 옵션을 확인하세요</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {restaurant.menus.map((menu) => {
                const isSelected = selectedMenu.id === menu.id;
                return (
                  <button
                    key={menu.id}
                    onClick={() => {
                      setSelectedMenu(menu);
                      setSelectedOptions([]);
                    }}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      isSelected
                        ? 'border-amber-500 bg-amber-50/60 shadow-xs'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs font-bold text-slate-900 mb-1">
                      <span className="truncate">{menu.name}</span>
                    </div>
                    <div className="text-xs font-semibold text-slate-700 tabular-nums">
                      {menu.price.toLocaleString()}원
                    </div>
                    <div className="text-[11px] text-slate-500 mt-1">
                      단백질 {menu.nutrition.proteinGrams}g · 포만감 {menu.fullnessScore}/5
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Selected Menu Spotlight & Nutrition */}
          <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="w-full sm:w-32 h-28 rounded-xl overflow-hidden bg-slate-200 shrink-0">
                <img
                  src={selectedMenu.imageUrl}
                  alt={selectedMenu.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h4 className="text-base font-bold text-slate-900">
                    {selectedMenu.name}
                  </h4>
                  {selectedMenu.isPopular && (
                    <span className="px-1.5 py-0.5 text-[10px] font-bold bg-amber-500 text-white rounded">
                      인기
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  {selectedMenu.description}
                </p>

                {/* Nutrition Box */}
                <div className="mt-3 p-2.5 bg-white rounded-xl border border-slate-200/80 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs">
                  <div className="flex items-center gap-1 font-semibold text-slate-900">
                    <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                    <span>단백질 {selectedMenu.nutrition.proteinGrams}g</span>
                  </div>
                  <div className="text-slate-600">
                    <span>열량 {selectedMenu.nutrition.calories} kcal</span>
                  </div>
                  {selectedMenu.nutrition.carbsGrams && (
                    <div className="text-slate-500">
                      탄수화물 {selectedMenu.nutrition.carbsGrams}g / 지방 {selectedMenu.nutrition.fatGrams}g
                    </div>
                  )}
                  {selectedMenu.nutrition.isVerified ? (
                    <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded font-medium ml-auto">
                      영양 성분 검증됨
                    </span>
                  ) : (
                    <span className="text-[10px] text-slate-400 ml-auto">
                      추정 영양치
                    </span>
                  )}
                </div>

                {/* Sauce & Rice detail */}
                <div className="mt-2 text-xs text-slate-500 space-y-0.5">
                  {selectedMenu.sauceStyle && (
                    <div>• 소스 제공: <span className="text-slate-800">{selectedMenu.sauceStyle}</span></div>
                  )}
                  {selectedMenu.portionCustomizable && (
                    <div>• 밥/면 양: <span className="text-slate-800">요청 시 보통/적게/많이 조절 가능</span></div>
                  )}
                </div>
              </div>
            </div>

            {/* Custom Options / Toppings */}
            {selectedMenu.options && selectedMenu.options.length > 0 && (
              <div className="pt-3 border-t border-slate-200/60">
                <div className="text-xs font-semibold text-slate-800 mb-2">
                  추가 토핑 및 옵션 선택
                </div>
                <div className="space-y-1.5">
                  {selectedMenu.options.map((opt) => {
                    const isChecked = selectedOptions.some((o) => o.id === opt.id);
                    return (
                      <label
                        key={opt.id}
                        className={`flex items-center justify-between p-2.5 rounded-xl border text-xs cursor-pointer transition-colors ${
                          isChecked
                            ? 'bg-amber-50/80 border-amber-300 text-slate-900 font-semibold'
                            : 'bg-white border-slate-200 hover:border-slate-300 text-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => toggleOption(opt)}
                            className="rounded text-amber-600 focus:ring-amber-500"
                          />
                          <span>{opt.name}</span>
                        </div>
                        <span className="tabular-nums font-bold">
                          {opt.price > 0 ? `+${opt.price.toLocaleString()}원` : '무료'}
                        </span>
                      </label>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer CTA */}
        <div className="sticky bottom-0 z-20 flex flex-col sm:flex-row items-center justify-between gap-3 px-6 py-4 bg-white border-t border-slate-200">
          <div className="w-full sm:w-auto flex items-baseline justify-between sm:justify-start gap-2">
            <span className="text-xs text-slate-500">선택 총 금액</span>
            <span className="text-xl font-bold text-slate-900 tabular-nums">
              {totalItemPrice.toLocaleString()}원
            </span>
          </div>

          <div className="w-full sm:w-auto flex items-center gap-2">
            <button
              onClick={() => {
                onStartGroupOrder(restaurant);
                onClose();
              }}
              className="flex-1 sm:flex-initial px-4 py-2.5 text-xs sm:text-sm font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors flex items-center justify-center gap-1.5"
            >
              <Users className="w-4 h-4 text-slate-600" />
              <span>동료와 함께 주문</span>
            </button>

            <button
              onClick={() => {
                onSelectMenuForSoloOrder(selectedMenu, selectedOptions);
                onClose();
              }}
              className="flex-1 sm:flex-initial px-5 py-2.5 text-xs sm:text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors shadow-xs flex items-center justify-center gap-1.5"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>바로 사전 주문하기</span>
            </button>
          </div>
        </div>

        {/* Mock Catchtable Info Modal */}
        {showCatchtableModal && (
          <div className="absolute inset-0 bg-slate-950/70 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-red-600">CATCHTABLE 웨이팅 연동</span>
                <button
                  onClick={() => setShowCatchtableModal(false)}
                  className="text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <h4 className="font-bold text-slate-900">{restaurant.name}</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                현재 원격 줄서기 대기팀은 <strong>{restaurant.waitTeamsCount || 2}팀</strong>입니다. 예상 대기시간은 약 <strong>10분</strong>이며 지금 대기를 접수하면 도착 시간에 맞춰 착석할 수 있습니다.
              </p>
              <div className="pt-2 flex gap-2">
                <button
                  onClick={() => setShowCatchtableModal(false)}
                  className="w-full py-2 bg-red-600 text-white rounded-xl text-xs font-bold hover:bg-red-700"
                >
                  확인 완료
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

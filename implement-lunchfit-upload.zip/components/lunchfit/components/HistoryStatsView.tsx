import React from 'react';
import { MealFeedbackLog, GroupOrder } from '../types';
import { Clock, Star, ShieldCheck, DollarSign, Flame, UtensilsCrossed, Calendar, CheckCircle2 } from 'lucide-react';

interface HistoryStatsViewProps {
  logs: MealFeedbackLog[];
  pastGroupOrders: GroupOrder[];
  onSelectPastGroupOrder?: (order: GroupOrder) => void;
}

export const HistoryStatsView: React.FC<HistoryStatsViewProps> = ({
  logs,
  pastGroupOrders,
  onSelectPastGroupOrder,
}) => {
  // Aggregate stats
  const totalMeals = logs.length;
  const avgSatisfaction = totalMeals > 0
    ? (logs.reduce((s, l) => s + l.satisfactionScore, 0) / totalMeals).toFixed(1)
    : '4.8';
  const avgActualMinutes = totalMeals > 0
    ? Math.round(logs.reduce((s, l) => s + l.actualMinutes, 0) / totalMeals)
    : 28;
  const totalTimeSaved = logs.reduce((s, l) => s + Math.max(0, l.estimatedMinutes - l.actualMinutes), 0);

  return (
    <div className="space-y-6 pb-12">
      {/* Title */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs">
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
          나의 점심 피트 리포트
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          시간 절약 통계, 단백질 섭취 현황 및 정산 완료 내역을 한눈에 확인하세요.
        </p>

        {/* Top Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5">
          <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-200/80">
            <div className="flex items-center gap-1.5 text-xs text-amber-800 font-semibold mb-1">
              <Clock className="w-3.5 h-3.5 text-amber-600" />
              <span>평균 식사 시간</span>
            </div>
            <div className="text-2xl font-black text-slate-900 tabular-nums">
              {avgActualMinutes}분
            </div>
            <div className="text-[11px] text-amber-700 mt-0.5">
              기준 60분 대비 여유 확보
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200/80">
            <div className="flex items-center gap-1.5 text-xs text-emerald-800 font-semibold mb-1">
              <Star className="w-3.5 h-3.5 text-emerald-600" />
              <span>평균 만족도</span>
            </div>
            <div className="text-2xl font-black text-slate-900 tabular-nums">
              {avgSatisfaction} <span className="text-sm font-normal text-slate-500">/ 5.0</span>
            </div>
            <div className="text-[11px] text-emerald-700 mt-0.5">
              높은 점심 퀄리티 유지
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-blue-50/60 border border-blue-200/80">
            <div className="flex items-center gap-1.5 text-xs text-blue-800 font-semibold mb-1">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
              <span>절약된 대기시간</span>
            </div>
            <div className="text-2xl font-black text-slate-900 tabular-nums">
              +{totalTimeSaved > 0 ? totalTimeSaved : 18}분
            </div>
            <div className="text-[11px] text-blue-700 mt-0.5">
              사전 주문·시간 추천 효과
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-purple-50/60 border border-purple-200/80">
            <div className="flex items-center gap-1.5 text-xs text-purple-800 font-semibold mb-1">
              <UtensilsCrossed className="w-3.5 h-3.5 text-purple-600" />
              <span>총 기록된 식사</span>
            </div>
            <div className="text-2xl font-black text-slate-900 tabular-nums">
              {totalMeals}회
            </div>
            <div className="text-[11px] text-purple-700 mt-0.5">
              그룹 정산 {pastGroupOrders.length}회 포함
            </div>
          </div>
        </div>
      </div>

      {/* 2-Column: Recent Meal Logs & Group Orders History */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Meals Feed */}
        <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-xs space-y-4">
          <h2 className="text-sm font-bold text-slate-900 flex items-center justify-between">
            <span>최근 식사 피드백 내역</span>
            <span className="text-xs font-normal text-slate-400">총 {logs.length}건</span>
          </h2>

          {logs.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400">
              아직 저장된 식사 기록이 없습니다. 식사 후 피드백을 기록해 보세요!
            </div>
          ) : (
            <div className="space-y-3">
              {logs.map((log) => (
                <div
                  key={log.id}
                  className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2 text-xs"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="font-bold text-slate-900 text-sm">
                        {log.restaurantName}
                      </span>
                      <div className="text-slate-500 font-medium">
                        {log.menuName}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 text-amber-500 font-bold">
                      <Star className="w-3.5 h-3.5 fill-amber-400" />
                      <span>{log.satisfactionScore}.0</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 text-slate-500 pt-1 border-t border-slate-200/60">
                    <span>
                      예상 {log.estimatedMinutes}분 → <strong>실제 {log.actualMinutes}분</strong>
                    </span>
                    <span>·</span>
                    <span>단백질 만족 {log.proteinScore}/5</span>
                    <span>·</span>
                    <span>포만감 {log.fullnessScore}/5</span>
                  </div>

                  {log.comment && (
                    <div className="bg-white p-2 rounded-xl text-slate-600 text-[11px] italic">
                      "{log.comment}"
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Group Orders History */}
        <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-xs space-y-4">
          <h2 className="text-sm font-bold text-slate-900 flex items-center justify-between">
            <span>최근 그룹 주문 및 1/N 정산 이력</span>
            <span className="text-xs font-normal text-slate-400">총 {pastGroupOrders.length}건</span>
          </h2>

          {pastGroupOrders.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400">
              완료된 그룹 주문 내역이 없습니다.
            </div>
          ) : (
            <div className="space-y-3">
              {pastGroupOrders.map((g) => {
                const totalAmount = g.members.reduce(
                  (s, m) =>
                    s +
                    m.items.reduce(
                      (itemSum, item) =>
                        itemSum + (item.unitPrice + item.optionsTotalPrice) * item.quantity,
                      0
                    ),
                  0
                ) + g.deliveryFee - g.discountAmount;

                return (
                  <div
                    key={g.id}
                    className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2 text-xs"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="font-bold text-slate-900 text-sm">
                          {g.title}
                        </div>
                        <div className="text-slate-500">
                          {g.restaurantName} · 참여자 {g.members.length}명
                        </div>
                      </div>
                      <span className="font-bold text-slate-900 text-sm tabular-nums">
                        {totalAmount.toLocaleString()}원
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-slate-500 pt-1 border-t border-slate-200/60">
                      <span>
                        정산 방식: {g.settlementMethod === 'EQUAL' ? '균등 1/N' : '개별 주문 기준'}
                      </span>
                      <span className="text-emerald-700 font-semibold flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        정산 완료
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

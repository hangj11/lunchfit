import React from 'react';
import { ScoredRestaurant } from '../utils/recommendation';
import { Clock, MapPin, Star, ShieldCheck, ChevronRight, ShoppingBag, Users, Zap, CheckCircle2, AlertTriangle } from 'lucide-react';

interface RestaurantCardProps {
  scored: ScoredRestaurant;
  onOpenDetail: () => void;
  onPreorder: () => void;
  onStartGroupOrder: () => void;
}

export const RestaurantCard: React.FC<RestaurantCardProps> = ({
  scored,
  onOpenDetail,
  onPreorder,
  onStartGroupOrder,
}) => {
  const { restaurant, timeFeasible, bufferMinutes, bestMatchingMenu, matchReasons } = scored;
  const [imageFailed, setImageFailed] = React.useState(false);

  return (
    <div
      className={`bg-white rounded-2xl border transition-all duration-200 overflow-hidden hover:shadow-md ${
        timeFeasible ? 'border-slate-200' : 'border-rose-200/80 bg-rose-50/10'
      }`}
    >
      <div className="p-4 sm:p-5">
        <div className="flex flex-col sm:flex-row gap-4">
          {/* Visual Thumbnail */}
          <div className="relative w-full sm:w-44 h-36 sm:h-auto rounded-xl overflow-hidden shrink-0 bg-slate-100">
            {!imageFailed ? (
              <img
                src={bestMatchingMenu.imageUrl || restaurant.imageUrl}
                alt={restaurant.name}
                referrerPolicy="no-referrer"
                onError={() => setImageFailed(true)}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-amber-50 to-orange-50 text-amber-800 p-2 text-center">
                <ShoppingBag className="w-6 h-6 text-amber-500 mb-1" />
                <span className="text-xs font-semibold">{restaurant.name}</span>
              </div>
            )}

            {/* Time status tag overlay */}
            <div className="absolute top-2 left-2 flex items-center gap-1.5 px-2 py-1 rounded-md text-[11px] font-semibold backdrop-blur-md shadow-xs bg-slate-900/80 text-white">
              <Clock className="w-3 h-3 text-amber-400" />
              <span>총 {restaurant.totalEstimatedMinutes}분</span>
            </div>

            {/* Realtime partner tag */}
            <div className="absolute bottom-2 left-2">
              {restaurant.isRealtimePartner ? (
                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium bg-emerald-500/90 text-white backdrop-blur-xs">
                  <CheckCircle2 className="w-2.5 h-2.5" />
                  실시간 연동
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium bg-slate-800/80 text-slate-200 backdrop-blur-xs">
                  예상치 기준
                </span>
              )}
            </div>
          </div>

          {/* Core Info */}
          <div className="flex-1 flex flex-col justify-between min-w-0">
            <div>
              {/* Header Line */}
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
                    <span>{restaurant.category}</span>
                    <span aria-hidden="true">·</span>
                    <span className="flex items-center gap-0.5 text-amber-600 font-semibold">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                      {restaurant.rating}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>리뷰 {restaurant.reviewCount}</span>
                  </div>
                  <h3
                    onClick={onOpenDetail}
                    className="text-base sm:text-lg font-bold text-slate-900 hover:text-amber-700 cursor-pointer transition-colors"
                  >
                    {restaurant.name}
                  </h3>
                </div>

                {/* Buffer badge */}
                <div>
                  {timeFeasible ? (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      {bufferMinutes}분 여유
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold bg-rose-50 text-rose-800 border border-rose-200">
                      <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                      {Math.abs(bufferMinutes)}분 초과 주의
                    </span>
                  )}
                </div>
              </div>

              {/* Time decomposition bar */}
              <div className="mt-2.5 p-2 rounded-xl bg-slate-50 border border-slate-100 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-600">
                <span className="font-semibold text-slate-700">시간 구성:</span>
                <span>도보 {restaurant.walkMinutes}분</span>
                <span className="text-slate-300">/</span>
                <span>준비 {restaurant.prepWaitMinutes}분</span>
                <span className="text-slate-300">/</span>
                <span>식사 {restaurant.eatMinutes}분</span>
                <span className="text-slate-300">/</span>
                <span>복귀 {restaurant.returnWalkMinutes}분</span>
                <span className="text-slate-400 font-normal">
                  (총 {restaurant.totalEstimatedMinutes}분 소요)
                </span>
              </div>

              {/* Recommended Menu Spotlight */}
              <div className="mt-3 flex items-center justify-between p-2.5 rounded-xl bg-amber-50/50 border border-amber-100/80">
                <div className="min-w-0 pr-2">
                  <div className="text-[11px] font-semibold text-amber-800 uppercase tracking-tight">
                    추천 대표 메뉴
                  </div>
                  <div className="text-xs sm:text-sm font-bold text-slate-900 truncate">
                    {bestMatchingMenu.name}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-2">
                    {bestMatchingMenu.nutrition.proteinGrams && (
                      <span>단백질 {bestMatchingMenu.nutrition.proteinGrams}g</span>
                    )}
                    <span aria-hidden="true">·</span>
                    <span>포만감 {bestMatchingMenu.fullnessScore}/5</span>
                    {bestMatchingMenu.portionCustomizable && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span>밥 양 선택 가능</span>
                      </>
                    )}
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <div className="text-sm sm:text-base font-bold text-slate-900 tabular-nums">
                    {bestMatchingMenu.price.toLocaleString()}원
                  </div>
                  <div className="text-[10px] text-slate-400">
                    {restaurant.currentStatus === 'WAITING_REQUIRED'
                      ? `대기 ${restaurant.waitTeamsCount || 1}팀`
                      : '즉시 입장'}
                  </div>
                </div>
              </div>

              {/* Match reasons tags */}
              <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
                {matchReasons.slice(0, 3).map((reason, idx) => (
                  <span
                    key={idx}
                    className="text-[11px] text-slate-500 font-medium px-2 py-0.5 rounded-md bg-slate-100"
                  >
                    ✓ {reason}
                  </span>
                ))}
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-1 text-xs text-slate-500 truncate max-w-[240px]">
                <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span className="truncate">{restaurant.locationDescription}</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onOpenDetail}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  메뉴·상세
                </button>

                {restaurant.canPreorder && (
                  <button
                    type="button"
                    onClick={onPreorder}
                    className="px-3 py-1.5 text-xs font-semibold text-amber-900 bg-amber-100 hover:bg-amber-200 rounded-lg transition-colors flex items-center gap-1"
                  >
                    <Zap className="w-3 h-3 text-amber-700" />
                    <span>사전 주문</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={onStartGroupOrder}
                  className="px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-1 shadow-xs"
                >
                  <Users className="w-3 h-3" />
                  <span>함께 주문</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

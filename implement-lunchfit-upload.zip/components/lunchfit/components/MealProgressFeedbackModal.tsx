import React from 'react';
import { MealFeedbackLog } from '../types';
import { Clock, CheckCircle2, Star, ThumbsUp, X, Sparkles, ChefHat, ShoppingBag, ArrowRight } from 'lucide-react';

interface MealProgressFeedbackModalProps {
  restaurantName: string;
  menuName: string;
  estimatedMinutes: number;
  onClose: () => void;
  onSaveFeedback: (feedback: MealFeedbackLog) => void;
}

export const MealProgressFeedbackModal: React.FC<MealProgressFeedbackModalProps> = ({
  restaurantName,
  menuName,
  estimatedMinutes,
  onClose,
  onSaveFeedback,
}) => {
  const [step, setStep] = React.useState<'COOKING' | 'READY' | 'FEEDBACK'>('COOKING');
  const [countdownMinutes, setCountdownMinutes] = React.useState(Math.min(estimatedMinutes, 6));
  
  // Feedback form fields
  const [actualMinutes, setActualMinutes] = React.useState(estimatedMinutes - 2);
  const [satisfaction, setSatisfaction] = React.useState(5);
  const [proteinScore, setProteinScore] = React.useState(5);
  const [fullnessScore, setFullnessScore] = React.useState(5);
  const [comment, setComment] = React.useState('정말 맛있고 시간 맞춰 먹어서 업무 복귀에 여유가 있었어요!');

  // Countdown timer effect
  React.useEffect(() => {
    if (step === 'COOKING') {
      const timer = setInterval(() => {
        setCountdownMinutes((prev) => {
          if (prev <= 1) {
            setStep('READY');
            return 0;
          }
          return prev - 1;
        });
      }, 3000); // simulated fast countdown
      return () => clearInterval(timer);
    }
  }, [step]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const log: MealFeedbackLog = {
      id: `feedback-${Date.now()}`,
      orderId: `order-${Date.now()}`,
      restaurantName,
      menuName,
      estimatedMinutes,
      actualMinutes,
      satisfactionScore: satisfaction,
      proteinScore,
      fullnessScore,
      comment,
      timestamp: Date.now(),
    };
    onSaveFeedback(log);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
            <span className="text-xs font-bold text-slate-900">
              {step === 'FEEDBACK' ? '식사 피드백 및 소요시간 기록' : '실시간 점심 진행 현황'}
            </span>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6">
          {step === 'COOKING' && (
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center mx-auto shadow-inner">
                <ChefHat className="w-8 h-8 animate-bounce" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">
                  {restaurantName}에서 조리 중입니다
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  메뉴: <strong>{menuName}</strong>
                </p>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 inline-block">
                <div className="text-xs text-slate-400 font-medium">픽업 / 준비 완료까지 약</div>
                <div className="text-3xl font-black text-slate-900 tabular-nums my-1">
                  {countdownMinutes}분
                </div>
                <div className="text-[11px] text-emerald-600 font-semibold">
                  ✓ 예정 시간 내 픽업 가능합니다
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => setStep('READY')}
                  className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
                >
                  (시뮬레이션) 픽업 완료로 이동
                </button>
              </div>
            </div>
          )}

          {step === 'READY' && (
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-inner">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">
                  메뉴 준비가 완료되었습니다!
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  카운터에서 <strong>LunchFit 픽업</strong>이라고 말씀해주세요.
                </p>
              </div>

              <button
                onClick={() => setStep('FEEDBACK')}
                className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl text-xs sm:text-sm font-bold shadow-md transition-colors flex items-center justify-center gap-2"
              >
                <span>맛있게 드셨나요? 식사 완료 기록하기</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {step === 'FEEDBACK' && (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  {restaurantName} 식사 만족도
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  실제 식사 시간과 만족도를 기록해 다음 추천 알고리즘을 최적화합니다.
                </p>
              </div>

              {/* Time Comparison */}
              <div className="p-3 bg-amber-50/50 rounded-2xl border border-amber-200/80 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-600 font-medium">예상 총 소요시간:</span>
                  <span className="font-bold text-slate-900">{estimatedMinutes}분</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-700 font-bold">실제 총 소요시간:</span>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="number"
                      min={10}
                      max={90}
                      value={actualMinutes}
                      onChange={(e) => setActualMinutes(Number(e.target.value))}
                      className="w-16 px-2 py-1 bg-white border border-slate-300 rounded-lg text-right font-bold text-xs"
                    />
                    <span className="font-bold">분</span>
                  </div>
                </div>
                <div className="text-[11px] text-emerald-700 font-medium">
                  {actualMinutes <= estimatedMinutes
                    ? `🎉 예상보다 ${estimatedMinutes - actualMinutes}분 빠르게 식사를 마쳤습니다!`
                    : `⚠️ 예상보다 ${actualMinutes - estimatedMinutes}분 지연되었습니다.`}
                </div>
              </div>

              {/* Star Rating */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 block">
                  전반적인 점심 만족도
                </label>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setSatisfaction(star)}
                      className="p-1 hover:scale-110 transition-transform"
                    >
                      <Star
                        className={`w-6 h-6 ${
                          star <= satisfaction
                            ? 'text-amber-400 fill-amber-400'
                            : 'text-slate-200'
                        }`}
                      />
                    </button>
                  ))}
                  <span className="text-xs font-bold text-slate-700 ml-2">
                    {satisfaction}점 / 5점
                  </span>
                </div>
              </div>

              {/* Protein & Fullness Rating */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-2.5 rounded-xl border border-slate-200 bg-slate-50">
                  <span className="font-semibold text-slate-700 block mb-1">
                    단백질 만족도
                  </span>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <button
                        key={s}
                        type="button"
                        onClick={() => setProteinScore(s)}
                        className={`w-6 h-6 rounded text-[11px] font-bold ${
                          proteinScore === s
                            ? 'bg-blue-600 text-white'
                            : 'bg-white text-slate-600 border border-slate-200'
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-2.5 rounded-xl border border-slate-200 bg-slate-50">
                  <span className="font-semibold text-slate-700 block mb-1">
                    포만감 지속도
                  </span>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <button
                        key={s}
                        type="button"
                        onClick={() => setFullnessScore(s)}
                        className={`w-6 h-6 rounded text-[11px] font-bold ${
                          fullnessScore === s
                            ? 'bg-orange-600 text-white'
                            : 'bg-white text-slate-600 border border-slate-200'
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Memo */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 block">
                  한줄 메모
                </label>
                <input
                  type="text"
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 py-2.5 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl"
                >
                  닫기
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl shadow-xs"
                >
                  기록 저장하기
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { UtensilsCrossed, Users, Clock, History, MapPin } from 'lucide-react';

interface HeaderProps {
  activeTab: 'recommend' | 'group' | 'history';
  onSelectTab: (tab: 'recommend' | 'group' | 'history') => void;
  locationCluster: string;
  onChangeLocation: (location: string) => void;
  activeGroupCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onSelectTab,
  locationCluster,
  onChangeLocation,
  activeGroupCount,
}) => {
  const [showLocationPicker, setShowLocationPicker] = React.useState(false);
  const locations = ['강남·테헤란로', '여의도 금융타운', '판교 테크노밸리', '광화문·을지로'];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex min-h-14 flex-wrap items-center justify-between gap-2 py-2 sm:min-h-16 sm:flex-nowrap sm:gap-4 sm:py-0">
          {/* Zone 1: Single text element wordmark */}
          <div className="flex min-w-0 items-center gap-2 sm:gap-3 shrink-0">
            <button
              onClick={() => onSelectTab('recommend')}
              className="flex items-center gap-2 text-left group"
            >
              <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold text-sm shadow-xs group-hover:scale-105 transition-transform">
                <UtensilsCrossed className="w-4 h-4" />
              </div>
              <div>
                <span className="text-lg font-bold tracking-tight text-slate-900">
                  LunchFit
                </span>
                <span className="hidden sm:inline-block ml-1.5 text-xs text-slate-400 font-normal">
                  직장인 점심 최적화
                </span>
              </div>
            </button>

            {/* Quick Location Switcher */}
            <div className="relative">
              <button
                onClick={() => setShowLocationPicker(!showLocationPicker)}
                className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-full transition-colors whitespace-nowrap"
                title="직장 위치 변경"
              >
                <MapPin className="w-3 h-3 text-amber-600" />
                <span>{locationCluster}</span>
              </button>

              {showLocationPicker && (
                <div className="absolute top-full left-0 mt-1 w-44 bg-white border border-slate-200 rounded-xl shadow-lg py-1.5 z-50">
                  <div className="px-3 py-1 text-[11px] font-semibold text-slate-400">
                    근무지 선택
                  </div>
                  {locations.map((loc) => (
                    <button
                      key={loc}
                      onClick={() => {
                        onChangeLocation(loc);
                        setShowLocationPicker(false);
                      }}
                      className={`w-full text-left px-3 py-1.5 text-xs hover:bg-amber-50 transition-colors ${
                        loc === locationCluster ? 'font-bold text-amber-700 bg-amber-50/50' : 'text-slate-700'
                      }`}
                    >
                      {loc}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Zone 2: Navigation tabs */}
          <nav className="order-3 -mx-1 flex w-[calc(100%+0.5rem)] items-center gap-1 overflow-x-auto px-1 pb-0.5 sm:order-none sm:mx-0 sm:w-auto sm:gap-2 sm:overflow-visible sm:px-0">
            <button
              onClick={() => onSelectTab('recommend')}
              className={`flex items-center gap-1.5 px-3.5 py-2 sm:px-5 sm:py-2.5 text-[13px] sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'recommend'
                  ? 'bg-amber-50 text-amber-900 border border-amber-200/80 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Clock className="w-4 h-4 text-amber-600" />
              <span>맞춤 추천</span>
            </button>

            <button
              onClick={() => onSelectTab('group')}
              className={`relative flex items-center gap-1.5 px-3.5 py-2 sm:px-5 sm:py-2.5 text-[13px] sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'group'
                  ? 'bg-amber-50 text-amber-900 border border-amber-200/80 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Users className="w-4 h-4 text-amber-600" />
              <span>함께 주문 & 1/N</span>
              {activeGroupCount > 0 && (
                <span className="w-2 h-2 rounded-full bg-amber-500" />
              )}
            </button>

            <button
              onClick={() => onSelectTab('history')}
              className={`flex items-center gap-1.5 px-3.5 py-2 sm:px-5 sm:py-2.5 text-[13px] sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'history'
                  ? 'bg-amber-50 text-amber-900 border border-amber-200/80 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <History className="w-4 h-4 text-amber-600" />
              <span>식사 기록</span>
            </button>
          </nav>

          {/* Zone 3: 1 Primary CTA */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => onSelectTab('group')}
              className="hidden md:inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs transition-colors whitespace-nowrap"
            >
              <Users className="w-3.5 h-3.5" />
              <span>새 그룹 주문</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

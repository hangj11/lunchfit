import { Restaurant, UserPreferences, PreferenceTag } from '../types';

export interface ScoredRestaurant {
  restaurant: Restaurant;
  timeFeasible: boolean;
  bufferMinutes: number; // availableTime - totalEstimated
  bestMatchingMenu: Restaurant['menus'][0];
  matchScore: number;
  matchReasons: string[];
}

export interface RecommendationResult {
  items: ScoredRestaurant[];
  totalCandidateCount: number;
  feasibleCount: number;
  relaxationAdvice?: string;
}

export type SortOption = 'BEST' | 'FAST' | 'PRICE' | 'PROTEIN' | 'FULLNESS' | 'RATING';

export function getRecommendations(
  restaurants: Restaurant[],
  prefs: UserPreferences,
  sortBy: SortOption = 'BEST'
): RecommendationResult {
  const scoredList: ScoredRestaurant[] = restaurants.map((restaurant) => {
    const totalTime = restaurant.totalEstimatedMinutes;
    const bufferMinutes = prefs.availableTimeMinutes - totalTime;
    const timeFeasible = bufferMinutes >= 0;

    // Find the best menu in this restaurant for the user's budget and preferences
    let candidateMenus = restaurant.menus;
    
    // Pick the most relevant menu
    let bestMenu = candidateMenus[0];
    let highestScore = -1;
    const matchReasons: string[] = [];

    for (const menu of candidateMenus) {
      let score = 50;

      // Budget scoring
      if (menu.price <= prefs.budgetWon) {
        score += 20;
      } else {
        score -= (menu.price - prefs.budgetWon) / 100; // penalize over-budget
      }

      // Preference tag scoring
      if (prefs.selectedTags.includes('FAST') && menu.speedScore >= 4) {
        score += 15;
      }
      if (prefs.selectedTags.includes('FULLNESS') && menu.fullnessScore >= 4) {
        score += 15;
      }
      if (prefs.selectedTags.includes('PROTEIN') && menu.nutrition.proteinGrams >= 30) {
        score += 20;
      }
      if (prefs.selectedTags.includes('HEALTHY') && menu.nutrition.calories <= 550) {
        score += 15;
      }
      if (prefs.selectedTags.includes('BUDGET') && menu.price <= 11000) {
        score += 15;
      }
      if (prefs.selectedTags.includes('TAKEOUT') && restaurant.canPickup) {
        score += 10;
      }

      if (score > highestScore) {
        highestScore = score;
        bestMenu = menu;
      }
    }

    // Match reasons generator
    if (timeFeasible) {
      matchReasons.push(`식사 후 ${bufferMinutes}분 여유`);
    } else {
      matchReasons.push(`식사 시간 ${Math.abs(bufferMinutes)}분 초과 예상`);
    }

    if (bestMenu.price <= prefs.budgetWon) {
      matchReasons.push(`예산 ${prefs.budgetWon.toLocaleString()}원 이내`);
    }

    if (bestMenu.nutrition.proteinGrams >= 30) {
      matchReasons.push(`단백질 ${bestMenu.nutrition.proteinGrams}g 고단백`);
    }

    if (restaurant.prepWaitMinutes <= 5) {
      matchReasons.push('주문 즉시 5분 내 준비');
    }

    if (restaurant.isRealtimePartner) {
      matchReasons.push('실시간 사전주문·픽업 지원');
    }

    // Overall match score
    let totalScore = highestScore + (restaurant.rating * 10);
    if (!timeFeasible) {
      totalScore -= 100; // Heavy penalty if time doesn't fit
    }

    return {
      restaurant,
      timeFeasible,
      bufferMinutes,
      bestMatchingMenu: bestMenu,
      matchScore: totalScore,
      matchReasons,
    };
  });

  // Sort logic
  const sorted = [...scoredList].sort((a, b) => {
    // If one is feasible and the other is not, feasible always comes first
    if (a.timeFeasible !== b.timeFeasible) {
      return a.timeFeasible ? -1 : 1;
    }

    switch (sortBy) {
      case 'FAST':
        return a.restaurant.totalEstimatedMinutes - b.restaurant.totalEstimatedMinutes;
      case 'PRICE':
        return a.bestMatchingMenu.price - b.bestMatchingMenu.price;
      case 'PROTEIN':
        return b.bestMatchingMenu.nutrition.proteinGrams - a.bestMatchingMenu.nutrition.proteinGrams;
      case 'FULLNESS':
        return b.bestMatchingMenu.fullnessScore - a.bestMatchingMenu.fullnessScore;
      case 'RATING':
        return b.restaurant.rating - a.restaurant.rating;
      case 'BEST':
      default:
        return b.matchScore - a.matchScore;
    }
  });

  const feasibleCount = sorted.filter((s) => s.timeFeasible).length;

  let relaxationAdvice: string | undefined = undefined;
  if (feasibleCount < 2) {
    // Find what would help
    const nearTimeMatches = restaurants.filter(
      (r) => r.totalEstimatedMinutes <= prefs.availableTimeMinutes + 15
    );
    if (nearTimeMatches.length > feasibleCount) {
      relaxationAdvice = `식사 시간을 10~15분 더 확보하거나 포장·픽업을 선택하시면 ${nearTimeMatches.length}곳의 맛집을 더 이용할 수 있어요.`;
    } else {
      relaxationAdvice = `예산을 2,000원 상향하시면 다양한 프리미엄 정식과 카츠 메뉴를 추천해 드릴 수 있어요.`;
    }
  }

  return {
    items: sorted,
    totalCandidateCount: restaurants.length,
    feasibleCount,
    relaxationAdvice,
  };
}

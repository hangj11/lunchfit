import { GroupOrder, SettlementSummary, MemberSettlementDetail } from '../types';

export function calculateSettlement(order: GroupOrder): SettlementSummary {
  const members = order.members;
  const memberCount = members.length;

  if (memberCount === 0) {
    return {
      totalFoodAmount: 0,
      deliveryFee: order.deliveryFee,
      discountAmount: order.discountAmount,
      finalTotalAmount: Math.max(0, order.deliveryFee - order.discountAmount),
      settlementMethod: order.settlementMethod,
      memberDetails: [],
      totalCollected: 0,
      allPaid: true,
    };
  }

  // Calculate individual food amounts
  const memberFoodTotals: { [memberId: string]: { food: number; options: number } } = {};
  let totalFoodAmount = 0;

  for (const member of members) {
    let food = 0;
    let options = 0;
    for (const item of member.items) {
      food += item.unitPrice * item.quantity;
      options += item.optionsTotalPrice * item.quantity;
    }
    memberFoodTotals[member.id] = { food, options };
    totalFoodAmount += food + options;
  }

  const finalTotalAmount = Math.max(0, totalFoodAmount + order.deliveryFee - order.discountAmount);

  const memberDetails: MemberSettlementDetail[] = [];

  if (order.settlementMethod === 'EQUAL') {
    // 1/N Equal split of the final total amount
    const baseShare = Math.floor(finalTotalAmount / memberCount);
    let remainder = finalTotalAmount - baseShare * memberCount;

    for (let i = 0; i < memberCount; i++) {
      const member = members[i];
      const personal = memberFoodTotals[member.id] || { food: 0, options: 0 };
      // Assign remainder (e.g. 1~2 won) to creator or first member for absolute parity
      const roundingAdjustment = member.isCreator ? remainder : 0;
      const finalAmount = baseShare + roundingAdjustment;

      memberDetails.push({
        memberId: member.id,
        memberName: member.name,
        isCreator: member.isCreator,
        foodAmount: personal.food,
        optionsAmount: personal.options,
        subtotal: personal.food + personal.options,
        deliveryShare: Math.floor(order.deliveryFee / memberCount),
        discountShare: Math.floor(order.discountAmount / memberCount),
        finalAmount,
        roundingAdjustment,
        isPaid: member.isPaid,
      });
    }
  } else {
    // BY_ORDER (Individual menu items + delivery fee share - discount share)
    let allocatedTotal = 0;
    const rawDetails: Array<{
      member: typeof members[0];
      food: number;
      options: number;
      subtotal: number;
      deliveryShare: number;
      discountShare: number;
      rawFinal: number;
    }> = [];

    for (const member of members) {
      const personal = memberFoodTotals[member.id] || { food: 0, options: 0 };
      const subtotal = personal.food + personal.options;

      // Delivery share
      let deliveryShare = 0;
      if (order.deliveryFeePolicy === 'CREATOR_PAYS') {
        deliveryShare = member.isCreator ? order.deliveryFee : 0;
      } else {
        deliveryShare = Math.floor(order.deliveryFee / memberCount);
      }

      // Discount share
      let discountShare = 0;
      if (order.discountAmount > 0) {
        if (order.discountPolicy === 'PROPORTIONAL' && totalFoodAmount > 0) {
          discountShare = Math.floor((subtotal / totalFoodAmount) * order.discountAmount);
        } else {
          discountShare = Math.floor(order.discountAmount / memberCount);
        }
      }

      const rawFinal = Math.max(0, subtotal + deliveryShare - discountShare);
      allocatedTotal += rawFinal;

      rawDetails.push({
        member,
        food: personal.food,
        options: personal.options,
        subtotal,
        deliveryShare,
        discountShare,
        rawFinal,
      });
    }

    // Exact won adjustment to ensure sum(members) === finalTotalAmount
    const diff = finalTotalAmount - allocatedTotal;

    for (const row of rawDetails) {
      const roundingAdjustment = row.member.isCreator ? diff : 0;
      const finalAmount = row.rawFinal + roundingAdjustment;

      memberDetails.push({
        memberId: row.member.id,
        memberName: row.member.name,
        isCreator: row.member.isCreator,
        foodAmount: row.food,
        optionsAmount: row.options,
        subtotal: row.subtotal,
        deliveryShare: row.deliveryShare,
        discountShare: row.discountShare,
        finalAmount,
        roundingAdjustment,
        isPaid: row.member.isPaid,
      });
    }
  }

  const totalCollected = memberDetails
    .filter((m) => m.isPaid)
    .reduce((sum, m) => sum + m.finalAmount, 0);

  const allPaid = memberDetails.length > 0 && memberDetails.every((m) => m.isPaid);

  return {
    totalFoodAmount,
    deliveryFee: order.deliveryFee,
    discountAmount: order.discountAmount,
    finalTotalAmount,
    settlementMethod: order.settlementMethod,
    memberDetails,
    totalCollected,
    allPaid,
  };
}

export function generateSettlementShareText(order: GroupOrder, settlement: SettlementSummary): string {
  const methodTitle = settlement.settlementMethod === 'EQUAL' ? '균등 1/N 정산' : '개별 주문 금액 기준 정산';
  const lines: string[] = [];

  lines.push(`🍽️ [LunchFit 점심 정산 안내]`);
  lines.push(`📌 그룹: ${order.title}`);
  lines.push(`🏪 식당: ${order.restaurantName}`);
  lines.push(`🏷️ 정산 방식: ${methodTitle}`);
  lines.push(`---------------------------`);
  lines.push(`• 음식 합계: ${settlement.totalFoodAmount.toLocaleString('ko-KR')}원`);
  if (settlement.deliveryFee > 0) {
    lines.push(`• 배달비: +${settlement.deliveryFee.toLocaleString('ko-KR')}원`);
  }
  if (settlement.discountAmount > 0) {
    lines.push(`• 할인 금액: -${settlement.discountAmount.toLocaleString('ko-KR')}원`);
  }
  lines.push(`💳 최종 결제 총액: ${settlement.finalTotalAmount.toLocaleString('ko-KR')}원`);
  lines.push(`---------------------------`);
  lines.push(`👥 개인별 입금 요청 금액:`);

  settlement.memberDetails.forEach((member) => {
    const creatorBadge = member.isCreator ? ' (그룹장)' : '';
    const paidBadge = member.isPaid ? ' [입금완료]' : ' [미입금]';
    lines.push(`- ${member.memberName}${creatorBadge}: ${member.finalAmount.toLocaleString('ko-KR')}원${paidBadge}`);
  });

  lines.push(`---------------------------`);
  lines.push(`💡 LunchFit으로 빠르고 깔끔하게 점심 완료!`);

  return lines.join('\n');
}

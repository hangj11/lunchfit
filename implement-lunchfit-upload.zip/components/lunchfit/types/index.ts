export type MealStyle = 'solo' | 'together' | 'takeout';

export type PreferenceTag = 
  | 'FAST'           // 빠른 식사
  | 'FULLNESS'       // 든든한 포만감
  | 'HEALTHY'        // 건강·다이어트
  | 'BUDGET'         // 가성비
  | 'PROTEIN'        // 고단백
  | 'CLEAN_TASTE'    // 깔끔·무난
  | 'TAKEOUT';       // 포장·픽업

export interface UserPreferences {
  availableTimeMinutes: number; // e.g. 45, 60
  budgetWon: number; // e.g. 12000
  selectedTags: PreferenceTag[];
  mealStyle: MealStyle;
  locationCluster: string; // e.g. "강남·테헤란로"
}

export interface MenuItemNutrition {
  calories: number;
  proteinGrams: number;
  carbsGrams?: number;
  fatGrams?: number;
  isVerified: boolean;
}

export interface MenuOption {
  id: string;
  name: string;
  price: number;
}

export interface MenuItem {
  id: string;
  restaurantId: string;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  category: string;
  isPopular?: boolean;
  isSoldOut?: boolean;
  nutrition: MenuItemNutrition;
  fullnessScore: number; // 1 to 5
  speedScore: number;    // 1 to 5 (5 is fast)
  sauceStyle?: string;   // e.g. "따로 제공 (찍먹)", "부먹", "선택 가능"
  portionCustomizable?: boolean; // e.g. "밥 양 보통/많이/적게 선택 가능"
  options?: MenuOption[];
}

export interface Restaurant {
  id: string;
  name: string;
  category: string;
  locationDescription: string;
  distanceMeters: number;
  walkMinutes: number;
  prepWaitMinutes: number;
  eatMinutes: number;
  returnWalkMinutes: number;
  totalEstimatedMinutes: number;
  priceRange: [number, number];
  rating: number;
  reviewCount: number;
  isRealtimePartner: boolean; // true: Catchtable / store direct link, false: estimated
  currentStatus: 'AVAILABLE' | 'CROWDED' | 'WAITING_REQUIRED';
  waitTeamsCount?: number;
  canPreorder: boolean;
  canPickup: boolean;
  canReservation: boolean;
  reservationPlatform?: 'CATCHTABLE' | 'DIRECT_PHONE' | 'NAVER';
  address: string;
  phone: string;
  businessHours: string;
  notice?: string;
  imageUrl: string;
  menus: MenuItem[];
}

export interface OrderItem {
  id: string;
  menuId: string;
  menuName: string;
  unitPrice: number;
  quantity: number;
  selectedOptions: MenuOption[];
  optionsTotalPrice: number;
  specialRequest?: string;
  memberId: string;
}

export interface GroupMember {
  id: string;
  name: string;
  avatarColor: string;
  isCreator: boolean;
  hasSubmitted: boolean;
  isPaid: boolean;
  items: OrderItem[];
}

export type GroupOrderStatus = 
  | 'CREATED'
  | 'COLLECTING'
  | 'REVIEW'
  | 'CONFIRMED'
  | 'COMPLETED'
  | 'CANCELLED';

export interface GroupOrder {
  id: string;
  title: string;
  creatorName: string;
  status: GroupOrderStatus;
  deadlineMinutesRemaining: number;
  deadlineTimeStr: string;
  restaurantId: string;
  restaurantName: string;
  restaurantCategory: string;
  members: GroupMember[];
  deliveryFee: number;
  discountAmount: number;
  settlementMethod: 'EQUAL' | 'BY_ORDER';
  deliveryFeePolicy: 'EQUAL' | 'CREATOR_PAYS';
  discountPolicy: 'PROPORTIONAL' | 'EQUAL';
  createdAt: number;
  confirmedAt?: number;
}

export interface MemberSettlementDetail {
  memberId: string;
  memberName: string;
  isCreator: boolean;
  foodAmount: number;
  optionsAmount: number;
  subtotal: number;
  deliveryShare: number;
  discountShare: number;
  finalAmount: number;
  roundingAdjustment: number;
  isPaid: boolean;
}

export interface SettlementSummary {
  totalFoodAmount: number;
  deliveryFee: number;
  discountAmount: number;
  finalTotalAmount: number;
  settlementMethod: 'EQUAL' | 'BY_ORDER';
  memberDetails: MemberSettlementDetail[];
  totalCollected: number;
  allPaid: boolean;
}

export interface MealFeedbackLog {
  id: string;
  orderId: string;
  restaurantName: string;
  menuName: string;
  estimatedMinutes: number;
  actualMinutes: number;
  satisfactionScore: number; // 1-5
  proteinScore: number;      // 1-5
  fullnessScore: number;     // 1-5
  comment: string;
  timestamp: number;
}

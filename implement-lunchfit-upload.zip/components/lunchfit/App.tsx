'use client';

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  UserPreferences, 
  Restaurant, 
  MenuItem, 
  MenuOption, 
  GroupOrder, 
  MealFeedbackLog, 
  MealStyle 
} from './types';
import { MOCK_RESTAURANTS } from './data/mockRestaurants';
import { getRecommendations, SortOption } from './utils/recommendation';
import { Header } from './components/Header';
import { PreferenceControls } from './components/PreferenceControls';
import { RestaurantCard } from './components/RestaurantCard';
import { RestaurantDetailModal } from './components/RestaurantDetailModal';
import { GroupOrderView } from './components/GroupOrderView';
import { MealProgressFeedbackModal } from './components/MealProgressFeedbackModal';
import { HistoryStatsView } from './components/HistoryStatsView';
import { 
  Clock, 
  SlidersHorizontal, 
  ArrowUpDown, 
  Info, 
  Users, 
  UtensilsCrossed, 
  History, 
  Sparkles,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

const INITIAL_PREFERENCES: UserPreferences = {
  availableTimeMinutes: 45,
  budgetWon: 13000,
  selectedTags: ['FAST', 'PROTEIN'],
  mealStyle: 'solo',
  locationCluster: '강남·테헤란로',
};

const DEFAULT_GROUP_ORDER: GroupOrder = {
  id: 'group-default-1',
  title: '프로젝트 TFT 점심회동',
  creatorName: '나 (그룹장)',
  status: 'COLLECTING',
  deadlineMinutesRemaining: 18,
  deadlineTimeStr: '11:45',
  restaurantId: 'rest-1',
  restaurantName: '든든 비빔곳간 강남테헤란점',
  restaurantCategory: '한식·솥밥·비빔밥',
  members: [
    {
      id: 'member-creator',
      name: '나 (그룹장)',
      avatarColor: 'bg-amber-500',
      isCreator: true,
      hasSubmitted: true,
      isPaid: true,
      items: [
        {
          id: 'item-init-1',
          menuId: 'menu-1-1',
          menuName: '한우 직화 불고기 비빔밥',
          unitPrice: 11500,
          quantity: 1,
          selectedOptions: [{ id: 'opt-1-1', name: '현미 귀리밥으로 변경 (+0원)', price: 0 }],
          optionsTotalPrice: 0,
          memberId: 'member-creator',
        },
      ],
    },
    {
      id: 'member-kim',
      name: '김대리',
      avatarColor: 'bg-blue-500',
      isCreator: false,
      hasSubmitted: true,
      isPaid: false,
      items: [
        {
          id: 'item-init-2',
          menuId: 'menu-1-2',
          menuName: '강릉 꼬막 초무침 비빔밥',
          unitPrice: 12500,
          quantity: 1,
          selectedOptions: [],
          optionsTotalPrice: 0,
          memberId: 'member-kim',
        },
      ],
    },
    {
      id: 'member-lee',
      name: '이선임',
      avatarColor: 'bg-emerald-500',
      isCreator: false,
      hasSubmitted: false,
      isPaid: false,
      items: [],
    },
  ],
  deliveryFee: 3000,
  discountAmount: 2000,
  settlementMethod: 'BY_ORDER',
  deliveryFeePolicy: 'EQUAL',
  discountPolicy: 'PROPORTIONAL',
  createdAt: Date.now() - 15 * 60 * 1000,
};

const INITIAL_LOGS: MealFeedbackLog[] = [
  {
    id: 'log-1',
    orderId: 'order-sample-1',
    restaurantName: '그린프로틴 샐러드 & 웜볼',
    menuName: '수비드 닭가슴살 아보카도 웜볼',
    estimatedMinutes: 24,
    actualMinutes: 20,
    satisfactionScore: 5,
    proteinScore: 5,
    fullnessScore: 4,
    comment: '픽업이 진짜 3분만에 나와서 산책까지 하고 복귀했습니다. 단백질도 든든!',
    timestamp: Date.now() - 86400000,
  },
  {
    id: 'log-2',
    orderId: 'order-sample-2',
    restaurantName: '카츠공방 테헤란본점',
    menuName: '초신선 히레카츠 정식 (안심)',
    estimatedMinutes: 42,
    actualMinutes: 38,
    satisfactionScore: 5,
    proteinScore: 5,
    fullnessScore: 5,
    comment: '원격 줄서기 걸어두고 가니 바로 입장했어요. 돈까스 바삭함 최고!',
    timestamp: Date.now() - 172800000,
  },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'recommend' | 'group' | 'history'>('recommend');
  const [locationCluster, setLocationCluster] = useState('강남·테헤란로');
  const [preferences, setPreferences] = useState<UserPreferences>(INITIAL_PREFERENCES);
  const [sortBy, setSortBy] = useState<SortOption>('BEST');
  
  // Selected restaurant for detail modal
  const [selectedRestaurant, setSelectedRestaurant] = useState<Restaurant | null>(null);

  // Group Order state
  const [groupOrder, setGroupOrder] = useState<GroupOrder>(() => {
    const saved = typeof window !== 'undefined' ? window.localStorage.getItem('lunchfit_active_group_order') : null;
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return DEFAULT_GROUP_ORDER;
      }
    }
    return DEFAULT_GROUP_ORDER;
  });

  const [pastGroupOrders, setPastGroupOrders] = useState<GroupOrder[]>([]);

  // Logs state
  const [feedbackLogs, setFeedbackLogs] = useState<MealFeedbackLog[]>(() => {
    const saved = typeof window !== 'undefined' ? window.localStorage.getItem('lunchfit_feedback_logs') : null;
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_LOGS;
      }
    }
    return INITIAL_LOGS;
  });

  // Active progress modal
  const [progressModal, setProgressModal] = useState<{
    isOpen: boolean;
    restaurantName: string;
    menuName: string;
    estimatedMinutes: number;
  } | null>(null);

  // Toast message
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Sync to local storage
  useEffect(() => {
    if (typeof window !== 'undefined') window.localStorage.setItem('lunchfit_active_group_order', JSON.stringify(groupOrder));
  }, [groupOrder]);

  useEffect(() => {
    if (typeof window !== 'undefined') window.localStorage.setItem('lunchfit_feedback_logs', JSON.stringify(feedbackLogs));
  }, [feedbackLogs]);

  // Compute recommendations
  const recommendationResult = getRecommendations(MOCK_RESTAURANTS, preferences, sortBy);

  // Handler: Start a new group order with specific restaurant
  const handleStartGroupOrder = (restaurant?: Restaurant) => {
    const targetRest = restaurant || MOCK_RESTAURANTS[0];
    const newOrder: GroupOrder = {
      id: `group-${Date.now()}`,
      title: `${targetRest.name.split(' ')[0]} 함께 먹어요`,
      creatorName: '나 (그룹장)',
      status: 'COLLECTING',
      deadlineMinutesRemaining: 20,
      deadlineTimeStr: '11:50',
      restaurantId: targetRest.id,
      restaurantName: targetRest.name,
      restaurantCategory: targetRest.category,
      members: [
        {
          id: 'member-creator',
          name: '나 (그룹장)',
          avatarColor: 'bg-amber-500',
          isCreator: true,
          hasSubmitted: false,
          isPaid: true,
          items: [],
        },
      ],
      deliveryFee: 3000,
      discountAmount: 0,
      settlementMethod: 'BY_ORDER',
      deliveryFeePolicy: 'EQUAL',
      discountPolicy: 'PROPORTIONAL',
      createdAt: Date.now(),
    };

    setGroupOrder(newOrder);
    setActiveTab('group');
    showToast(`'${targetRest.name}' 그룹 주문이 생성되었습니다.`);
  };

  // Handler: Switch restaurant inside group order
  const handleSwitchRestaurantInGroup = (newRestaurantId: string) => {
    const target = MOCK_RESTAURANTS.find((r) => r.id === newRestaurantId);
    if (!target) return;

    setGroupOrder((prev) => ({
      ...prev,
      restaurantId: target.id,
      restaurantName: target.name,
      restaurantCategory: target.category,
    }));
    showToast(`식당이 '${target.name}'으로 변경되었습니다.`);
  };

  // Handler: Preorder a menu for solo dining
  const handleSoloPreorder = (menu: MenuItem, options: MenuOption[]) => {
    const targetRest = MOCK_RESTAURANTS.find((r) => r.id === menu.restaurantId);
    setProgressModal({
      isOpen: true,
      restaurantName: targetRest?.name || '식당',
      menuName: menu.name,
      estimatedMinutes: targetRest?.prepWaitMinutes || 6,
    });
  };

  // Handler: Complete group order & start tracking
  const handleCompleteGroupOrder = () => {
    setGroupOrder((prev) => ({
      ...prev,
      status: 'CONFIRMED',
      confirmedAt: Date.now(),
    }));

    setPastGroupOrders((prev) => [groupOrder, ...prev]);

    setProgressModal({
      isOpen: true,
      restaurantName: groupOrder.restaurantName,
      menuName: `${groupOrder.members.length}인 그룹 주문`,
      estimatedMinutes: 25,
    });
  };

  // Handler: Save feedback log
  const handleSaveFeedback = (newLog: MealFeedbackLog) => {
    setFeedbackLogs((prev) => [newLog, ...prev]);
    showToast('소중한 식사 피드백이 저장되었습니다!');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col antialiased">
      {/* Top Header Bar */}
      <Header
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        locationCluster={locationCluster}
        onChangeLocation={setLocationCluster}
        activeGroupCount={groupOrder.status === 'COLLECTING' ? 1 : 0}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 md:pb-12">
        {activeTab === 'recommend' && (
          <div className="space-y-6">
            {/* Preference Controls Card */}
            <PreferenceControls
              preferences={preferences}
              onChangePreferences={setPreferences}
              onReset={() => setPreferences(INITIAL_PREFERENCES)}
              onStartGroupOrder={() => handleStartGroupOrder()}
            />

            {/* Results Filter & Sort Strip */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-slate-900">
                  추천 식당 {recommendationResult.feasibleCount}곳
                </span>
                <span className="text-xs text-slate-400">
                  (전체 후보 {recommendationResult.totalCandidateCount}곳 중 식사 가능 시간 내 매장)
                </span>
              </div>

              {/* Sort Tabs */}
              <div className="flex items-center gap-1 p-1 bg-white border border-slate-200 rounded-xl text-xs overflow-x-auto">
                <button
                  onClick={() => setSortBy('BEST')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition-colors whitespace-nowrap ${
                    sortBy === 'BEST'
                      ? 'bg-slate-900 text-white font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  종합 추천순
                </button>
                <button
                  onClick={() => setSortBy('FAST')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition-colors whitespace-nowrap ${
                    sortBy === 'FAST'
                      ? 'bg-slate-900 text-white font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  가장 빠른순
                </button>
                <button
                  onClick={() => setSortBy('PRICE')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition-colors whitespace-nowrap ${
                    sortBy === 'PRICE'
                      ? 'bg-slate-900 text-white font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  낮은 가격순
                </button>
                <button
                  onClick={() => setSortBy('PROTEIN')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition-colors whitespace-nowrap ${
                    sortBy === 'PROTEIN'
                      ? 'bg-slate-900 text-white font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  고단백순
                </button>
                <button
                  onClick={() => setSortBy('FULLNESS')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition-colors whitespace-nowrap ${
                    sortBy === 'FULLNESS'
                      ? 'bg-slate-900 text-white font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  든든 포만감순
                </button>
              </div>
            </div>

            {/* Intelligent Relaxation Advice Banner (FR-01, FR-02) */}
            {recommendationResult.relaxationAdvice && (
              <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-900 flex items-start gap-2.5">
                <Info className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <div className="leading-relaxed">
                  <span className="font-semibold">더 많은 선택지를 원하시나요?</span>{' '}
                  {recommendationResult.relaxationAdvice}
                </div>
              </div>
            )}

            {/* Restaurant Cards Feed */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {recommendationResult.items.map((scored) => (
                <RestaurantCard
                  key={scored.restaurant.id}
                  scored={scored}
                  onOpenDetail={() => setSelectedRestaurant(scored.restaurant)}
                  onPreorder={() => {
                    handleSoloPreorder(scored.bestMatchingMenu, []);
                  }}
                  onStartGroupOrder={() => {
                    handleStartGroupOrder(scored.restaurant);
                  }}
                />
              ))}
            </div>
          </div>
        )}

        {/* Tab 2: Group Order & 1/N Settlement */}
        {activeTab === 'group' && (
          <GroupOrderView
            order={groupOrder}
            restaurants={MOCK_RESTAURANTS}
            onUpdateOrder={setGroupOrder}
            onCompleteOrder={handleCompleteGroupOrder}
            onCancelOrder={() => setGroupOrder(DEFAULT_GROUP_ORDER)}
            onSwitchRestaurant={handleSwitchRestaurantInGroup}
          />
        )}

        {/* Tab 3: History & Personal Stats */}
        {activeTab === 'history' && (
          <HistoryStatsView
            logs={feedbackLogs}
            pastGroupOrders={pastGroupOrders}
          />
        )}
      </main>

      {/* Mobile Ergonomic Bottom Tab Navigation Bar (PRD Section 10_mobile_touch_apps) */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 md:hidden pb-safe">
        <div className="grid grid-cols-3 items-center h-16 px-4">
          <button
            onClick={() => setActiveTab('recommend')}
            className={`flex flex-col items-center justify-center min-h-[44px] transition-colors ${
              activeTab === 'recommend' ? 'text-amber-600 font-bold' : 'text-slate-500'
            }`}
          >
            <Clock className="w-5 h-5 mb-0.5" />
            <span className="text-[11px]">점심 추천</span>
          </button>

          <button
            onClick={() => setActiveTab('group')}
            className={`relative flex flex-col items-center justify-center min-h-[44px] transition-colors ${
              activeTab === 'group' ? 'text-amber-600 font-bold' : 'text-slate-500'
            }`}
          >
            <Users className="w-5 h-5 mb-0.5" />
            <span className="text-[11px]">함께 주문 1/N</span>
            {groupOrder.status === 'COLLECTING' && (
              <span className="absolute top-1.5 right-6 w-2 h-2 rounded-full bg-amber-500" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('history')}
            className={`flex flex-col items-center justify-center min-h-[44px] transition-colors ${
              activeTab === 'history' ? 'text-amber-600 font-bold' : 'text-slate-500'
            }`}
          >
            <History className="w-5 h-5 mb-0.5" />
            <span className="text-[11px]">식사 기록</span>
          </button>
        </div>
      </nav>

      {/* Restaurant Detail Modal */}
      {selectedRestaurant && (
        <RestaurantDetailModal
          restaurant={selectedRestaurant}
          onClose={() => setSelectedRestaurant(null)}
          onSelectMenuForSoloOrder={(menu, options) => {
            handleSoloPreorder(menu, options);
          }}
          onStartGroupOrder={(r) => {
            handleStartGroupOrder(r);
          }}
        />
      )}

      {/* Progress & Feedback Modal */}
      {progressModal && progressModal.isOpen && (
        <MealProgressFeedbackModal
          restaurantName={progressModal.restaurantName}
          menuName={progressModal.menuName}
          estimatedMinutes={progressModal.estimatedMinutes}
          onClose={() => setProgressModal(null)}
          onSaveFeedback={handleSaveFeedback}
        />
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 md:bottom-8 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white text-xs sm:text-sm font-semibold px-4 py-2.5 rounded-full shadow-lg flex items-center gap-2 animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
